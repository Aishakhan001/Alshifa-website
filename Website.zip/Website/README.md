# Al-Shifa Institute of Health Sciences – Four-Page Website

Lab Task 3 – Web Development (HTML5 Semantic Elements & External CSS)

## Pages
- `index.html` – Home
- `about.html` – About
- `services.html` – Services / Courses
- `contact.html` – Contact (with form)
- `style.css` – single shared stylesheet
- `images/` – hero illustration

## Run locally
Open `index.html` in any browser.

## Live site (GitHub Pages)
Repository Settings → Pages → Source: *Deploy from a branch* → `main` / `/ (root)`.
